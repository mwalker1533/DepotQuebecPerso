# -*- coding: utf-8 -*-
"""
scrapper.py — API scraper for Noovo (noovo.ca).
Python 3 / Kodi 20+ compatible.

Noovo uses:
  1. Their own REST API at api.noovo.ca for show/episode listings
  2. Brightcove Playback API (account 618566855001) for video streams

The old plugin scraped HTML and did video['data-video-id'] which caused
NoneType crashes whenever the page structure changed. This version uses
the proper JSON APIs directly.
"""

import urllib.parse
import xbmc

from resources.lib import http

# Noovo API
NOOVO_API = 'https://api.noovo.ca/api/v1'

# Brightcove Playback API — Noovo's account
BRIGHTCOVE_ACCOUNT = '618566855001'
BRIGHTCOVE_API = f'https://edge.api.brightcove.com/playback/v1/accounts/{BRIGHTCOVE_ACCOUNT}'

# Brightcove policy key — required in the Accept header.
# This is the public policy key for Noovo's Brightcove account.
# It must be sent as: Accept: application/json;pk=<KEY>
BRIGHTCOVE_POLICY_KEY = 'BCpkADawqM0T8lW3nMChuAbrcunBBHmh4YkNl5e6ZrKd74sL0nGEONkZGMp3fKZMSjPnCOt_DQ9zW4xNJlcx6yGiVj9F5LVdlJHQ-a8'


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Noovo] {msg}', level)


def get_categories():
    """
    Get the main content categories from Noovo.

    Returns:
        list of dicts: [{id, title, thumb}, ...]
    """
    url = f'{NOOVO_API}/pages/home'
    data = http.get(url, is_json=True)

    if not data:
        # Fallback to known categories
        _log('API unavailable, using fallback categories', xbmc.LOGWARNING)
        return [
            {'id': 'emissions',     'title': 'Toutes les émissions', 'thumb': ''},
            {'id': 'tele',          'title': 'Noovo',                'thumb': ''},
          	{'id': 'musiqueplus',   'title': 'MusiquePlus',          'thumb': ''},
            {'id': 'serie',         'title': 'Séries',               'thumb': ''},
            {'id': 'telerealite',   'title': 'Téléréalité',          'thumb': ''},
            {'id': 'documentaire',  'title': 'Documentaires',        'thumb': ''},
            {'id': 'jeunesse',      'title': 'Jeunesse',             'thumb': ''},
        ]

    categories = []
    sections = data.get('data', {}).get('sections') or data.get('sections') or []
    for section in sections:
        if not isinstance(section, dict):
            continue
        title = section.get('title') or section.get('name', '')
        section_id = section.get('slug') or section.get('id', '')
        thumb = section.get('image', {}).get('url', '') if isinstance(section.get('image'), dict) else ''
        if title and section_id:
            categories.append({'id': section_id, 'title': title, 'thumb': thumb})

    return categories if categories else get_categories()  # recurse to fallback if empty


def get_shows(category=None):
    """
    Get list of shows, optionally filtered by category slug.

    Returns:
        list of dicts: [{id, title, description, thumb, slug}, ...]
    """
    if category:
        url = f'{NOOVO_API}/pages/emissions/{urllib.parse.quote(category)}'
    else:
        url = f'{NOOVO_API}/pages/emissions'

    data = http.get(url, is_json=True)
    if not data:
        return []

    shows = []
    raw_shows = (
        data.get('data', {}).get('shows') or
        data.get('data', {}).get('items') or
        data.get('shows') or
        data.get('items') or
        []
    )

    for show in raw_shows:
        if not isinstance(show, dict):
            continue

        show_id = show.get('slug') or show.get('id', '')
        title = show.get('title') or show.get('name', 'Sans titre')
        desc = show.get('description') or show.get('summary', '')

        # Noovo image structure: image.url or image.formats.large.url
        image = show.get('image') or {}
        if isinstance(image, dict):
            thumb = (
                image.get('url') or
                (image.get('formats', {}) or {}).get('large', {}).get('url', '') or
                ''
            )
        else:
            thumb = str(image)

        if not show_id:
            continue

        shows.append({
            'id': show_id,
            'title': title,
            'description': desc,
            'thumb': thumb,
        })

    return shows


def get_episodes(show_slug):
    """
    Get episodes for a show by its slug.

    Returns:
        list of dicts: [{brightcove_id, title, description, thumb, season, episode, duration}, ...]
    """
    url = f'{NOOVO_API}/pages/emissions/{urllib.parse.quote(show_slug)}/episodes'
    data = http.get(url, is_json=True)

    if not data:
        # Try alternate endpoint
        url = f'{NOOVO_API}/pages/single-show/{urllib.parse.quote(show_slug)}'
        data = http.get(url, is_json=True)

    if not data:
        return []

    episodes = []
    raw_eps = (
        data.get('data', {}).get('episodes') or
        data.get('data', {}).get('items') or
        data.get('episodes') or
        data.get('items') or
        []
    )

    # Sometimes nested in seasons
    if not raw_eps:
        seasons = data.get('data', {}).get('seasons') or data.get('seasons') or []
        for season in seasons:
            if isinstance(season, dict):
                raw_eps.extend(season.get('episodes') or [])

    for ep in raw_eps:
        if not isinstance(ep, dict):
            continue

        # brightcoveId is the key field — this is what broke the old plugin
        # (it tried to get data-video-id from scraped HTML instead)
        brightcove_id = (
            ep.get('brightcoveId') or
            ep.get('brightcove_id') or
            ep.get('videoId') or
            ep.get('video_id') or
            ''
        )

        if not brightcove_id:
            _log(f'Skipping episode with no brightcoveId: {ep.get("title", "?")}', xbmc.LOGWARNING)
            continue

        title = ep.get('title') or ep.get('name', 'Sans titre')
        desc = ep.get('description') or ep.get('summary', '')

        image = ep.get('image') or {}
        thumb = image.get('url', '') if isinstance(image, dict) else str(image)

        season = ep.get('season') or ep.get('seasonNumber') or 0
        episode = ep.get('episode') or ep.get('episodeNumber') or 0
        duration = ep.get('duration') or 0

        episodes.append({
            'brightcove_id': str(brightcove_id),
            'title': title,
            'description': desc,
            'thumb': thumb,
            'season': int(season) if season else 0,
            'episode': int(episode) if episode else 0,
            'duration': int(duration) if duration else 0,
        })

    return episodes


def get_stream_url(brightcove_id):
    """
    Resolve the HLS stream URL for a Brightcove video ID.

    Uses the Brightcove Playback API with Noovo's policy key in the Accept header.
    This replaces the old HTML scraping approach that caused NoneType crashes.

    Args:
        brightcove_id (str): The Brightcove video ID (e.g. '4293298759001')

    Returns:
        str | None: Best available HLS stream URL, or None on failure.
    """
    url = f'{BRIGHTCOVE_API}/videos/{brightcove_id}'
    _log(f'Fetching Brightcove stream for video {brightcove_id}')

    data = http.get(url, is_json=True, extra_headers={
        'Accept': f'application/json;pk={BRIGHTCOVE_POLICY_KEY}',
    })

    if not data:
        _log(f'No data from Brightcove for video {brightcove_id}', xbmc.LOGERROR)
        return None

    sources = data.get('sources') or []
    if not sources:
        _log(f'No sources in Brightcove response for {brightcove_id}', xbmc.LOGERROR)
        return None

    # Prefer HLS (m3u8) streams — prioritize HTTPS
    hls_sources = [
        s for s in sources
        if isinstance(s, dict) and
        s.get('src', '').startswith('https') and
        (s.get('type') == 'application/x-mpegURL' or '.m3u8' in s.get('src', ''))
    ]

    if hls_sources:
        # Pick highest quality if multiple available
        stream_url = hls_sources[0].get('src', '')
        _log(f'Found HLS stream: {stream_url[:80]}...')
        return stream_url

    # Fallback: any MP4 source over HTTPS
    mp4_sources = [
        s for s in sources
        if isinstance(s, dict) and
        s.get('src', '').startswith('https') and
        s.get('container') == 'MP4'
    ]

    if mp4_sources:
        # Sort by height (quality) descending
        mp4_sources.sort(key=lambda s: s.get('height', 0), reverse=True)
        stream_url = mp4_sources[0].get('src', '')
        _log(f'Falling back to MP4 stream: {stream_url[:80]}...')
        return stream_url

    _log(f'Could not find any playable stream for {brightcove_id}', xbmc.LOGERROR)
    return None

# -*- coding: utf-8 -*-
"""
scrapper.py — API scraper for ICI Tou.TV.
Python 3 / Kodi 20+ compatible.

Key fix: deviceType changed from 'iphone4' (broken) to 'ioscenc' (working).
This was the #1 reported bug causing "Aucun DRM n'est supporté" errors.
"""

import urllib.parse
import xbmc

from resources.lib import http

# Radio-Canada / Tou.TV API endpoints
API_BASE = 'https://services.radio-canada.ca/toutv/profiling/v1'
MEDIA_API = 'https://services.radio-canada.ca/media/meta/v1'
VALIDATION_API = 'https://services.radio-canada.ca/media/validation/v2'
CAROUSEL_API = 'https://services.radio-canada.ca/toutv/profiling/v2'

# Fixed: was 'iphone4' which causes "426 Upgrade Required" and DRM errors
DEVICE_TYPE = 'ioscenc'
APP_CODE = 'toutv'
CONNECTION_TYPE = 'wifi'


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Tou.TV] {msg}', level)


def get_categories():
    """
    Fetch the list of content categories/sections from Tou.TV.

    Returns:
        list of dicts with keys: id, title, url
    """
    url = f'{API_BASE}/page/toutv?device=web'
    data = http.get(url, is_json=True)

    if not data:
        return []

    categories = []

    # Try to extract sections from the page structure
    sections = data.get('sections') or data.get('categories') or []
    if isinstance(sections, list):
        for section in sections:
            if not isinstance(section, dict):
                continue
            title = section.get('title') or section.get('name', '')
            section_id = section.get('id') or section.get('url', '')
            if title and section_id:
                categories.append({
                    'id': section_id,
                    'title': title,
                    'thumb': section.get('image') or section.get('thumbnail', ''),
                })

    # Fallback: hardcoded known categories if API shape changed
    if not categories:
        _log('Could not parse categories from API, using fallback list', xbmc.LOGWARNING)
        categories = [
            {'id': 'emissions', 'title': 'Toutes les émissions', 'thumb': ''},
            {'id': 'recents',   'title': 'Récemment ajoutés',    'thumb': ''},
            {'id': 'series',    'title': 'Séries',                'thumb': ''},
            {'id': 'documentaires', 'title': 'Documentaires',    'thumb': ''},
            {'id': 'enfants',   'title': 'Jeunesse',              'thumb': ''},
        ]

    return categories


def get_shows(category_id=None):
    """
    Fetch all shows, optionally filtered by category.

    Returns:
        list of dicts with keys: id, title, description, thumb, url
    """
    if category_id:
        url = f'{API_BASE}/page/{urllib.parse.quote(category_id)}?device=web'
    else:
        url = f'{API_BASE}/page/emissions?device=web'

    data = http.get(url, is_json=True)
    if not data:
        return []

    shows = []
    items = (
        data.get('items') or
        data.get('shows') or
        data.get('emissions') or
        []
    )

    for item in items:
        if not isinstance(item, dict):
            continue
        show_id = item.get('id') or item.get('url') or item.get('Url', '')
        title = item.get('title') or item.get('Title') or item.get('name', 'Sans titre')
        desc = item.get('description') or item.get('Description') or item.get('summary', '')
        thumb = (
            item.get('image') or
            item.get('thumbnail') or
            item.get('ImageUrl') or
            item.get('Thumbnail', '')
        )
        if not show_id:
            continue
        shows.append({
            'id': show_id,
            'title': title,
            'description': desc,
            'thumb': thumb,
        })

    return shows


def get_episodes(show_id):
    """
    Fetch episodes for a given show.

    Args:
        show_id (str): The show URL/ID.

    Returns:
        list of dicts with keys: id, title, description, thumb, season, episode, duration
    """
    url = f'{API_BASE}/page/{urllib.parse.quote(show_id)}?device=web'
    data = http.get(url, is_json=True)

    if not data:
        return []

    episodes = []
    items = (
        data.get('episodes') or
        data.get('items') or
        data.get('Episodes') or
        []
    )

    # Sometimes episodes are nested inside seasons
    if not items:
        seasons = data.get('seasons') or data.get('Seasons') or []
        for season in seasons:
            if isinstance(season, dict):
                season_eps = season.get('episodes') or season.get('Episodes') or []
                items.extend(season_eps)

    for ep in items:
        if not isinstance(ep, dict):
            continue

        ep_id = ep.get('id') or ep.get('IdMedia') or ep.get('idMedia', '')
        title = ep.get('title') or ep.get('Title') or ep.get('name', 'Sans titre')
        desc = ep.get('description') or ep.get('Description') or ep.get('summary', '')
        thumb = (
            ep.get('image') or
            ep.get('thumbnail') or
            ep.get('ImageUrl') or
            ep.get('Thumbnail', '')
        )
        season = ep.get('season') or ep.get('Season') or ep.get('SeasonNumber', 0)
        episode = ep.get('episode') or ep.get('Episode') or ep.get('EpisodeNumber', 0)
        duration = ep.get('duration') or ep.get('Duration') or ep.get('length', 0)

        if not ep_id:
            continue

        episodes.append({
            'id': str(ep_id),
            'title': title,
            'description': desc,
            'thumb': thumb,
            'season': int(season) if season else 0,
            'episode': int(episode) if episode else 0,
            'duration': int(duration) if duration else 0,
        })

    return episodes


def get_stream_url(media_id, claims=None):
    """
    Resolve the HLS stream URL for a given media ID.

    This is the function that was broken due to deviceType='iphone4'.
    Now uses deviceType='ioscenc' which is one of the three working types.

    Args:
        media_id (str): The media ID to resolve.
        claims (str): Optional claims token for authenticated content.

    Returns:
        str | None: The HLS stream URL, or None on failure.
    """
    params = {
        'appCode': APP_CODE,
        'deviceType': DEVICE_TYPE,  # Fixed: was 'iphone4'
        'connectionType': CONNECTION_TYPE,
        'idMedia': media_id,
        'output': 'json',
    }
    if claims:
        params['claims'] = claims

    url = f'{VALIDATION_API}?' + urllib.parse.urlencode(params)
    _log(f'Resolving stream for media {media_id} with deviceType={DEVICE_TYPE}')

    data = http.get(url, is_json=True)
    if not data:
        return None

    # Extract stream URL from various possible response shapes
    stream_url = (
        data.get('url') or
        data.get('Url') or
        data.get('streamUrl') or
        data.get('hls') or
        data.get('HLS')
    )

    # Sometimes nested under a 'params' or 'videoUrl' key
    if not stream_url:
        params_block = data.get('params') or data.get('Params') or {}
        stream_url = params_block.get('url') or params_block.get('videoUrl', '')

    if stream_url:
        _log(f'Resolved stream URL: {stream_url[:80]}...')
    else:
        _log(f'Could not extract stream URL from response: {data}', xbmc.LOGERROR)

    return stream_url or None


def get_media_meta(media_id):
    """
    Fetch metadata for a media item (title, description, thumbnail).

    Args:
        media_id (str): The media ID.

    Returns:
        dict | None
    """
    url = f'{MEDIA_API}/medias/{media_id}?appCode={APP_CODE}'
    return http.get(url, is_json=True)

# YouTube Music pour Kodi — Instructions d'installation

## Étape 1 — Installer les dépendances

Ce plugin nécessite deux bibliothèques Python. Sur votre appareil Android/PC,
ouvrez un terminal et tapez:

```
pip install ytmusicapi yt-dlp
```

Sur Android (Kodi), ouvrez un terminal (ex: Termux) et tapez:
```
pip install ytmusicapi yt-dlp
```

## Étape 2 — Installer le plugin dans Kodi

1. Dans Kodi: **Addons → Installer depuis un fichier ZIP**
2. Sélectionnez `plugin.audio.ytmusic-1.0.0.zip`
3. Attendez la confirmation

## Étape 3 — Configurer l'authentification

Pour accéder à votre bibliothèque personnelle (playlists, chansons aimées, etc.),
vous devez copier votre cookie de session YouTube Music.

### Comment obtenir votre cookie:

1. Ouvrez **Chrome** ou **Firefox** sur votre PC
2. Allez sur **music.youtube.com** et connectez-vous à votre compte Google
3. Appuyez sur **F12** pour ouvrir les outils de développement
4. Cliquez sur l'onglet **Réseau** (Network)
5. Dans la barre de filtre, tapez **/browse**
6. Cliquez sur n'importe quelle chanson ou parcourez la bibliothèque
   pour générer une requête
7. Cliquez sur la requête **/browse** qui apparaît dans la liste
8. Dans le panneau de droite, cliquez sur **En-têtes de requête**
9. Trouvez la ligne **cookie:** et copiez TOUTE la valeur (c'est long!)
10. Dans Kodi, lancez YouTube Music → cliquez **Configurer l'authentification**
11. Collez le cookie dans la boîte de texte

### Note importante:
- Le cookie reste valide environ **2 ans**
- Vous n'avez besoin de refaire cette étape que si vous vous déconnectez
  de YouTube dans votre navigateur

## Étape 4 — Profitez!

Votre bibliothèque, playlists et chansons aimées sont maintenant accessibles
directement dans Kodi. Faites un **appui long** sur n'importe quel élément
pour l'ajouter aux favoris Kodi.

---

## Dépannage

**"yt-dlp not installed"** → Relancez `pip install yt-dlp` dans un terminal

**Bibliothèque vide** → Vérifiez que votre cookie contient bien `SAPISID=`

**Chanson ne joue pas** → Mettez yt-dlp à jour: `pip install -U yt-dlp`

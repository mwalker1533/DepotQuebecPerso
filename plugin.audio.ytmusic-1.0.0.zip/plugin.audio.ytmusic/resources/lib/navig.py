# -*- coding: utf-8 -*-
"""
navig.py — Navigation for YouTube Music Kodi addon.
Handles all menu building, directory listings and playback.
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import ytapi, auth

ADDON = xbmcaddon.Addon()
PLUGIN_URL = sys.argv[0]
PLUGIN_HANDLE = int(sys.argv[1])


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[YTMusic] {msg}', level)


def _show_error(msg):
    xbmcgui.Dialog().ok('YouTube Music', msg)


def _show_notification(msg, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification('YouTube Music', msg, icon)


def build_url(params):
    return PLUGIN_URL + '?' + urllib.parse.urlencode(params)


def _auth_path():
    return auth.get_auth_path()


def _add_item(label, params, art=None, info=None, is_folder=True, is_playable=False, add_favourite=False):
    """Universal helper to add any directory item."""
    url = build_url(params)
    li = xbmcgui.ListItem(label)

    if art:
        li.setArt(art)

    if info:
        li.setInfo('music', info)

    if is_playable:
        li.setProperty('IsPlayable', 'true')

    if add_favourite:
        li.addContextMenuItems([
            (f'Ajouter "{label}" aux favoris', 'Action(AddFavourite)')
        ])

    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, is_folder)


# ─── Main Menu ────────────────────────────────────────────────────────────────

def show_main_menu():
    """Main menu — different options based on auth status."""
    is_auth = auth.is_configured()

    if not is_auth:
        # Show setup prompt
        _add_item(
            '⚙️ Configurer l\'authentification',
            {'action': 'setup'},
            info={'title': 'Configuration requise'},
        )
        _add_item(
            '🔍 Rechercher (sans compte)',
            {'action': 'search'},
            info={'title': 'Recherche'},
        )
    else:
        _add_item('🏠 Accueil / Recommandations', {'action': 'home'},
                  info={'title': 'Accueil'})
        _add_item('❤️  Chansons aimées',          {'action': 'liked_songs'},
                  info={'title': 'Chansons aimées'})
        _add_item('📋 Mes playlists',              {'action': 'library_playlists'},
                  info={'title': 'Playlists'})
        _add_item('💿 Albums sauvegardés',         {'action': 'library_albums'},
                  info={'title': 'Albums'})
        _add_item('🎤 Artistes suivis',            {'action': 'library_artists'},
                  info={'title': 'Artistes'})
        _add_item('🔍 Rechercher',                 {'action': 'search'},
                  info={'title': 'Recherche'})
        _add_item('⚙️ Reconfigurer / Déconnecter', {'action': 'setup'},
                  info={'title': 'Configuration'})

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ─── Home / Recommendations ───────────────────────────────────────────────────

def show_home():
    """Show home screen recommendations as sections."""
    sections = ytapi.get_home(_auth_path())

    if not sections:
        _show_error('Impossible de charger les recommandations.\nVérifiez votre connexion et votre authentification.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for section in sections:
        title = section.get('title', 'Section')
        items = section.get('items', [])

        if not items:
            continue

        # Add section header as a non-clickable label
        li = xbmcgui.ListItem(f'── {title} ──')
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, '', li, False)

        for item in items:
            _add_item_from_parsed(item, add_favourite=True)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ─── Library ──────────────────────────────────────────────────────────────────

def show_liked_songs():
    """Show user's liked songs."""
    tracks = ytapi.get_liked_songs(_auth_path())

    if not tracks:
        _show_error('Aucune chanson aimée trouvée.\nAssurez-vous d\'être bien authentifié.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for track in tracks:
        if not track or not track.get('id'):
            continue
        _add_track_item(track)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'songs')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_library_playlists():
    """Show user's playlists."""
    playlists = ytapi.get_library_playlists(_auth_path())

    if not playlists:
        _show_error('Aucune playlist trouvée dans votre bibliothèque.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for pl in playlists:
        count = pl.get('count', '')
        label = f"{pl['title']}  ({count} titres)" if count else pl['title']
        _add_item(
            label=label,
            params={'action': 'playlist_tracks', 'playlist_id': pl['id']},
            art={'thumb': pl['thumb'], 'icon': pl['thumb']},
            info={'title': pl['title'], 'mediatype': 'music'},
            add_favourite=True,
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'albums')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_library_albums():
    """Show user's saved albums."""
    albums = ytapi.get_library_albums(_auth_path())

    if not albums:
        _show_error('Aucun album trouvé dans votre bibliothèque.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for album in albums:
        artist = album.get('artist', '')
        year = album.get('year', '')
        label = f"{album['title']}"
        if artist:
            label += f"  — {artist}"
        if year:
            label += f"  ({year})"

        _add_item(
            label=label,
            params={'action': 'album_tracks', 'browse_id': album['id']},
            art={'thumb': album['thumb'], 'icon': album['thumb']},
            info={
                'title': album['title'],
                'artist': artist,
                'year': int(year) if year and year.isdigit() else 0,
                'mediatype': 'album',
            },
            add_favourite=True,
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'albums')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_ALBUM)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_library_artists():
    """Show user's followed artists."""
    artists = ytapi.get_library_artists(_auth_path())

    if not artists:
        _show_error('Aucun artiste trouvé dans votre bibliothèque.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for artist in artists:
        _add_item(
            label=artist['title'],
            params={'action': 'artist', 'browse_id': artist['id']},
            art={'thumb': artist['thumb'], 'icon': artist['thumb']},
            info={'title': artist['title'], 'mediatype': 'artist'},
            add_favourite=True,
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'artists')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_ARTIST)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ─── Content Pages ────────────────────────────────────────────────────────────

def show_playlist_tracks(playlist_id):
    """Show tracks in a playlist."""
    tracks = ytapi.get_playlist_tracks(playlist_id, _auth_path())

    if not tracks:
        _show_error('Cette playlist est vide ou inaccessible.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for track in tracks:
        if not track or not track.get('id'):
            continue
        _add_track_item(track)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_album_tracks(browse_id):
    """Show tracks in an album."""
    tracks = ytapi.get_album_tracks(browse_id, _auth_path())

    if not tracks:
        _show_error('Cet album est vide ou inaccessible.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for i, track in enumerate(tracks, 1):
        if not track or not track.get('id'):
            continue
        _add_track_item(track, track_number=i)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_artist(browse_id):
    """Show an artist's content: top songs, albums, singles."""
    data = ytapi.get_artist_content(browse_id, _auth_path())

    if not data:
        _show_error('Impossible de charger le contenu de cet artiste.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    artist_name = data.get('name', 'Artiste')

    # Top songs
    songs_section = data.get('songs', {})
    if songs_section:
        results = songs_section.get('results') or []
        browse_id_songs = (songs_section.get('browseId') or '')
        if results:
            _add_item(
                f'🎵 Meilleures chansons de {artist_name}',
                {'action': 'playlist_tracks', 'playlist_id': browse_id_songs} if browse_id_songs
                else {'action': 'artist_songs', 'browse_id': browse_id},
                info={'title': f'Meilleures chansons'},
            )

    # Albums
    albums_section = data.get('albums', {})
    albums = (albums_section.get('results') or []) if albums_section else []
    for album in albums[:10]:
        if not isinstance(album, dict):
            continue
        ab_id = album.get('browseId', '')
        if not ab_id:
            continue
        _add_item(
            label=f"💿 {album.get('title', 'Album')} ({album.get('year', '')})",
            params={'action': 'album_tracks', 'browse_id': ab_id},
            art={'thumb': ytapi._extract_thumb(album.get('thumbnails'))},
            info={'title': album.get('title', ''), 'mediatype': 'album'},
            add_favourite=True,
        )

    # Singles
    singles_section = data.get('singles', {})
    singles = (singles_section.get('results') or []) if singles_section else []
    for single in singles[:5]:
        if not isinstance(single, dict):
            continue
        s_id = single.get('browseId', '')
        if not s_id:
            continue
        _add_item(
            label=f"🎵 {single.get('title', 'Single')} ({single.get('year', '')})",
            params={'action': 'album_tracks', 'browse_id': s_id},
            art={'thumb': ytapi._extract_thumb(single.get('thumbnails'))},
            info={'title': single.get('title', ''), 'mediatype': 'album'},
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'albums')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ─── Search ───────────────────────────────────────────────────────────────────

def show_search():
    """Prompt user to type a search query."""
    query = xbmcgui.Dialog().input(
        'Rechercher sur YouTube Music',
        type=xbmcgui.INPUT_ALPHANUM
    )

    if not query:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    show_search_results(query)


def show_search_results(query):
    """Show search results for a query."""
    results = ytapi.search(query, auth_path=_auth_path())

    if not results:
        _show_error(f'Aucun résultat pour "{query}".')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for item in results:
        _add_item_from_parsed(item, add_favourite=True)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ─── Playback ─────────────────────────────────────────────────────────────────

def play_song(video_id):
    """Extract and play an audio stream for a YouTube video ID."""
    _log(f'Playing video_id={video_id}')

    # Show a brief loading notification
    _show_notification('Chargement en cours...')

    stream_info = ytapi.get_stream_url(video_id)

    if not stream_info or not stream_info.get('url'):
        _show_error(
            'Impossible de lire cette chanson.\n'
            'Assurez-vous que yt-dlp est installé et à jour.\n'
            'Commande: pip install -U yt-dlp'
        )
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, False, xbmcgui.ListItem())
        return

    stream_url = stream_info['url']
    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('music', {
        'title': stream_info.get('title', ''),
        'duration': stream_info.get('duration', 0),
    })

    # Set MIME type based on format
    ext = stream_info.get('ext', 'webm')
    if ext == 'webm' or ext == 'opus':
        li.setMimeType('audio/webm')
    elif ext == 'm4a' or ext == 'mp4':
        li.setMimeType('audio/mp4')
    else:
        li.setMimeType('audio/mpeg')

    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)


# ─── Private helpers ──────────────────────────────────────────────────────────

def _add_track_item(track, track_number=None):
    """Add a single playable track to the directory."""
    title = track.get('title', 'Sans titre')
    artist = track.get('artist', '')
    album = track.get('album', '')
    thumb = track.get('thumb', '')
    duration = track.get('duration', 0)
    video_id = track.get('id', '')

    label = title
    if artist:
        label = f'{artist} — {title}'

    li = xbmcgui.ListItem(label)
    li.setProperty('IsPlayable', 'true')
    li.setArt({'thumb': thumb, 'icon': thumb})
    li.setInfo('music', {
        'title': title,
        'artist': artist,
        'album': album,
        'duration': duration,
        'tracknumber': track_number or 0,
        'mediatype': 'song',
    })
    li.addContextMenuItems([
        (f'Ajouter "{title}" aux favoris', 'Action(AddFavourite)')
    ])

    url = build_url({'action': 'play', 'video_id': video_id})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, False)


def _add_item_from_parsed(item, add_favourite=False):
    """Route a parsed item to the correct add function based on type."""
    if not item:
        return

    item_type = item.get('type', '')

    if item_type == 'song':
        _add_track_item(item)

    elif item_type == 'playlist':
        _add_item(
            label=f"📋 {item.get('title', 'Playlist')}",
            params={'action': 'playlist_tracks', 'playlist_id': item.get('id', '')},
            art={'thumb': item.get('thumb', '')},
            info={'title': item.get('title', '')},
            add_favourite=add_favourite,
        )

    elif item_type == 'album':
        artist = item.get('artist', '')
        label = f"💿 {item.get('title', 'Album')}"
        if artist:
            label += f"  — {artist}"
        _add_item(
            label=label,
            params={'action': 'album_tracks', 'browse_id': item.get('id', '')},
            art={'thumb': item.get('thumb', '')},
            info={'title': item.get('title', ''), 'artist': artist},
            add_favourite=add_favourite,
        )

    elif item_type == 'artist':
        _add_item(
            label=f"🎤 {item.get('title', 'Artiste')}",
            params={'action': 'artist', 'browse_id': item.get('id', '')},
            art={'thumb': item.get('thumb', '')},
            info={'title': item.get('title', '')},
            add_favourite=add_favourite,
        )

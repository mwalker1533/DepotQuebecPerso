# -*- coding: utf-8 -*-
"""
auth.py — Authentication for YouTube Music Kodi addon.

YouTube Music requires browser cookies for authenticated requests (library,
playlists, liked songs). This module handles storing and loading those cookies
securely within Kodi's addon profile directory.

Setup process for user:
  1. Open YouTube Music in their browser (music.youtube.com)
  2. Open DevTools (F12) → Network tab
  3. Filter by /browse
  4. Copy the Cookie header value from any request
  5. Paste it into the Kodi addon settings
"""

import json
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
AUTH_FILE = os.path.join(PROFILE_PATH, 'auth.json')


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[YTMusic] {msg}', level)


def is_configured():
    """Check if authentication has been set up."""
    return os.path.exists(AUTH_FILE)


def get_auth_path():
    """Return the path to the auth file, or None if not configured."""
    if is_configured():
        return AUTH_FILE
    return None


def save_auth(cookie_string):
    """
    Parse and save browser cookie string as ytmusicapi-compatible auth JSON.

    Args:
        cookie_string (str): Raw Cookie header value from browser DevTools.

    Returns:
        bool: True if saved successfully.
    """
    if not cookie_string or not cookie_string.strip():
        return False

    # Build the auth JSON structure ytmusicapi expects
    auth_data = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept": "*/*",
        "Accept-Language": "fr-CA,fr;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "X-Goog-AuthUser": "0",
        "x-origin": "https://music.youtube.com",
        "Cookie": cookie_string.strip(),
    }

    # Try to extract Authorization from cookie if present
    # (some browser exports include it)
    if 'SAPISID' in cookie_string:
        _log('SAPISID found in cookie — auth should work correctly')

    try:
        os.makedirs(PROFILE_PATH, exist_ok=True)
        with open(AUTH_FILE, 'w', encoding='utf-8') as f:
            json.dump(auth_data, f, indent=2)
        _log('Auth saved successfully')
        return True
    except Exception as e:
        _log(f'Failed to save auth: {e}', xbmc.LOGERROR)
        return False


def clear_auth():
    """Remove saved authentication."""
    try:
        if os.path.exists(AUTH_FILE):
            os.remove(AUTH_FILE)
            _log('Auth cleared')
        return True
    except Exception as e:
        _log(f'Failed to clear auth: {e}', xbmc.LOGERROR)
        return False


def run_setup():
    """
    Interactive setup wizard shown to the user inside Kodi.
    Guides them through copying their browser cookie.
    """
    dialog = xbmcgui.Dialog()

    # Step 1 — Explain what to do
    dialog.ok(
        'YouTube Music — Configuration',
        (
            'Pour accéder à votre bibliothèque personnelle, vous devez copier '
            'votre cookie de session YouTube Music.\n\n'
            'Étapes:\n'
            '1. Ouvrez music.youtube.com dans Chrome/Firefox\n'
            '2. Appuyez sur F12 (DevTools) → onglet Réseau\n'
            '3. Filtrez par "/browse"\n'
            '4. Cliquez sur une requête → En-têtes\n'
            '5. Copiez la valeur du champ "cookie"\n'
            '6. Collez-la dans le prochain écran'
        )
    )

    # Step 2 — Let them paste the cookie
    cookie = dialog.input(
        'Collez votre cookie YouTube Music ici',
        type=xbmcgui.INPUT_ALPHANUM
    )

    if not cookie:
        dialog.notification(
            'YouTube Music',
            'Configuration annulée',
            xbmcgui.NOTIFICATION_WARNING
        )
        return False

    # Step 3 — Save it
    if save_auth(cookie):
        dialog.ok(
            'YouTube Music — Succès!',
            (
                'Authentification configurée avec succès!\n\n'
                'Vous pouvez maintenant accéder à votre bibliothèque, '
                'vos playlists et vos chansons aimées.\n\n'
                'Note: Votre cookie reste valide environ 2 ans.'
            )
        )
        return True
    else:
        dialog.ok(
            'YouTube Music — Erreur',
            'Impossible de sauvegarder l\'authentification.\nVeuillez réessayer.'
        )
        return False

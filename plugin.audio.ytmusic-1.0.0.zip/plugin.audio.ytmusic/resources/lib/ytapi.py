# -*- coding: utf-8 -*-
"""
ytapi.py — YouTube Music API wrapper for Kodi addon.

Uses:
  - ytmusicapi: for browsing library, playlists, search, home recommendations
  - yt-dlp: for extracting audio-only stream URLs from video IDs
"""

import xbmc
import xbmcaddon
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[YTMusic] {msg}', level)


def _get_ytmusic(auth_path=None):
    """
    Create and return a YTMusic instance.
    If auth_path is provided, returns an authenticated instance.
    Otherwise returns an unauthenticated instance (limited features).
    """
    try:
        from ytmusicapi import YTMusic
        if auth_path and os.path.exists(auth_path):
            _log(f'Creating authenticated YTMusic instance')
            return YTMusic(auth_path, language='fr')
        else:
            _log('Creating unauthenticated YTMusic instance')
            return YTMusic(language='fr')
    except ImportError:
        _log('ytmusicapi not installed!', xbmc.LOGERROR)
        return None
    except Exception as e:
        _log(f'Failed to create YTMusic instance: {e}', xbmc.LOGERROR)
        return None


def get_home(auth_path=None):
    """
    Get home screen recommendations.

    Returns:
        list of sections, each with title and list of items
    """
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        home = yt.get_home(limit=5)
        results = []
        for section in (home or []):
            if not isinstance(section, dict):
                continue
            title = section.get('title', '')
            contents = section.get('contents') or []
            items = []
            for item in contents:
                if not isinstance(item, dict):
                    continue
                parsed = _parse_item(item)
                if parsed:
                    items.append(parsed)
            if items:
                results.append({'title': title, 'items': items})
        return results
    except Exception as e:
        _log(f'get_home error: {e}', xbmc.LOGERROR)
        return []


def get_library_playlists(auth_path):
    """Get user's playlists from their library."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        playlists = yt.get_library_playlists(limit=50) or []
        results = []
        for pl in playlists:
            if not isinstance(pl, dict):
                continue
            results.append({
                'type': 'playlist',
                'id': pl.get('playlistId', ''),
                'title': pl.get('title', 'Sans titre'),
                'count': pl.get('count', ''),
                'thumb': _extract_thumb(pl.get('thumbnails')),
            })
        return results
    except Exception as e:
        _log(f'get_library_playlists error: {e}', xbmc.LOGERROR)
        return []


def get_library_albums(auth_path):
    """Get user's saved albums from their library."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        albums = yt.get_library_albums(limit=50) or []
        results = []
        for album in albums:
            if not isinstance(album, dict):
                continue
            results.append({
                'type': 'album',
                'id': album.get('browseId', ''),
                'title': album.get('title', 'Sans titre'),
                'artist': _extract_artist(album.get('artists')),
                'year': album.get('year', ''),
                'thumb': _extract_thumb(album.get('thumbnails')),
            })
        return results
    except Exception as e:
        _log(f'get_library_albums error: {e}', xbmc.LOGERROR)
        return []


def get_library_artists(auth_path):
    """Get user's followed artists from their library."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        artists = yt.get_library_artists(limit=50) or []
        results = []
        for artist in artists:
            if not isinstance(artist, dict):
                continue
            results.append({
                'type': 'artist',
                'id': artist.get('browseId', ''),
                'title': artist.get('artist', 'Sans titre'),
                'thumb': _extract_thumb(artist.get('thumbnails')),
            })
        return results
    except Exception as e:
        _log(f'get_library_artists error: {e}', xbmc.LOGERROR)
        return []


def get_liked_songs(auth_path):
    """Get user's liked songs playlist."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        liked = yt.get_liked_songs(limit=200)
        tracks = (liked or {}).get('tracks') or []
        return [_parse_track(t) for t in tracks if isinstance(t, dict)]
    except Exception as e:
        _log(f'get_liked_songs error: {e}', xbmc.LOGERROR)
        return []


def get_playlist_tracks(playlist_id, auth_path=None):
    """Get tracks from a playlist."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        playlist = yt.get_playlist(playlist_id, limit=200)
        tracks = (playlist or {}).get('tracks') or []
        return [_parse_track(t) for t in tracks if isinstance(t, dict)]
    except Exception as e:
        _log(f'get_playlist_tracks error: {e}', xbmc.LOGERROR)
        return []


def get_album_tracks(browse_id, auth_path=None):
    """Get tracks from an album."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        album = yt.get_album(browse_id)
        tracks = (album or {}).get('tracks') or []
        thumb = _extract_thumb((album or {}).get('thumbnails'))
        album_title = (album or {}).get('title', '')
        artist = _extract_artist((album or {}).get('artists'))

        results = []
        for t in tracks:
            if not isinstance(t, dict):
                continue
            parsed = _parse_track(t)
            # Fill in album-level thumb/artist if track doesn't have them
            if not parsed.get('thumb') and thumb:
                parsed['thumb'] = thumb
            if not parsed.get('artist') and artist:
                parsed['artist'] = artist
            if not parsed.get('album') and album_title:
                parsed['album'] = album_title
            results.append(parsed)
        return results
    except Exception as e:
        _log(f'get_album_tracks error: {e}', xbmc.LOGERROR)
        return []


def get_artist_content(browse_id, auth_path=None):
    """Get an artist's top songs, albums and singles."""
    yt = _get_ytmusic(auth_path)
    if not yt:
        return {}

    try:
        artist = yt.get_artist(browse_id)
        return artist or {}
    except Exception as e:
        _log(f'get_artist_content error: {e}', xbmc.LOGERROR)
        return {}


def search(query, filter_type=None, auth_path=None):
    """
    Search YouTube Music.

    Args:
        query (str): Search query.
        filter_type (str): 'songs', 'albums', 'artists', 'playlists', or None for all.

    Returns:
        list of result dicts
    """
    yt = _get_ytmusic(auth_path)
    if not yt:
        return []

    try:
        results = yt.search(query, filter=filter_type, limit=30) or []
        parsed = []
        for item in results:
            if not isinstance(item, dict):
                continue
            result_type = item.get('resultType', '')

            if result_type == 'song':
                parsed.append(_parse_track(item))
            elif result_type == 'album':
                parsed.append({
                    'type': 'album',
                    'id': item.get('browseId', ''),
                    'title': item.get('title', 'Sans titre'),
                    'artist': _extract_artist(item.get('artists')),
                    'year': item.get('year', ''),
                    'thumb': _extract_thumb(item.get('thumbnails')),
                })
            elif result_type == 'artist':
                parsed.append({
                    'type': 'artist',
                    'id': item.get('browseId', ''),
                    'title': item.get('artist', item.get('title', 'Sans titre')),
                    'thumb': _extract_thumb(item.get('thumbnails')),
                })
            elif result_type == 'playlist':
                parsed.append({
                    'type': 'playlist',
                    'id': item.get('playlistId', ''),
                    'title': item.get('title', 'Sans titre'),
                    'thumb': _extract_thumb(item.get('thumbnails')),
                })

        return [p for p in parsed if p]
    except Exception as e:
        _log(f'search error: {e}', xbmc.LOGERROR)
        return []


def get_stream_url(video_id):
    """
    Extract the best audio-only stream URL for a YouTube video ID using yt-dlp.

    This is the core playback function. yt-dlp handles all the complexity
    of YouTube's stream signing and format selection.

    Args:
        video_id (str): YouTube video ID (e.g. 'dQw4w9WgXcQ')

    Returns:
        dict with keys: url, title, duration, or None on failure
    """
    try:
        import yt_dlp
    except ImportError:
        _log('yt-dlp not installed! Please install via pip.', xbmc.LOGERROR)
        return None

    url = f'https://www.youtube.com/watch?v={video_id}'
    _log(f'Extracting stream for video_id={video_id}')

    # yt-dlp options — audio only, best quality, no download
    ydl_opts = {
        'format': 'bestaudio/best',
        'quiet': True,
        'no_warnings': True,
        'extract_flat': False,
        'noplaylist': True,
        # Store yt-dlp cache in addon profile to avoid permission issues
        'cachedir': os.path.join(PROFILE_PATH, 'yt_dlp_cache'),
        # Don't actually download anything
        'skip_download': True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)

        if not info:
            _log(f'No info returned for {video_id}', xbmc.LOGERROR)
            return None

        stream_url = info.get('url', '')
        if not stream_url:
            # Try to get from formats list
            formats = info.get('formats') or []
            audio_formats = [
                f for f in formats
                if f.get('acodec') != 'none' and f.get('vcodec') == 'none'
            ]
            if audio_formats:
                # Pick best audio quality
                audio_formats.sort(key=lambda f: f.get('abr') or 0, reverse=True)
                stream_url = audio_formats[0].get('url', '')

        if not stream_url:
            _log(f'No stream URL found for {video_id}', xbmc.LOGERROR)
            return None

        return {
            'url': stream_url,
            'title': info.get('title', ''),
            'duration': info.get('duration', 0),
            'ext': info.get('ext', 'webm'),
        }

    except Exception as e:
        _log(f'yt-dlp extraction failed for {video_id}: {e}', xbmc.LOGERROR)
        return None


# ─── Private helpers ──────────────────────────────────────────────────────────

def _parse_track(item):
    """Parse a track dict from ytmusicapi into a standard format."""
    if not isinstance(item, dict):
        return None

    video_id = item.get('videoId', '')
    title = item.get('title', 'Sans titre')
    artist = _extract_artist(item.get('artists'))
    album = ''
    album_data = item.get('album')
    if isinstance(album_data, dict):
        album = album_data.get('name', '')
    elif isinstance(album_data, str):
        album = album_data

    duration_raw = item.get('duration') or item.get('duration_seconds') or 0
    duration = int(duration_raw) if isinstance(duration_raw, (int, float)) else 0

    return {
        'type': 'song',
        'id': video_id,
        'title': title,
        'artist': artist,
        'album': album,
        'duration': duration,
        'thumb': _extract_thumb(item.get('thumbnails')),
    }


def _parse_item(item):
    """Parse a generic item from home/browse results."""
    result_type = item.get('resultType') or item.get('type', '')

    if item.get('videoId'):
        return _parse_track(item)
    elif item.get('playlistId'):
        return {
            'type': 'playlist',
            'id': item.get('playlistId', ''),
            'title': item.get('title', 'Sans titre'),
            'thumb': _extract_thumb(item.get('thumbnails')),
        }
    elif item.get('browseId'):
        # Could be album or artist
        return {
            'type': result_type or 'album',
            'id': item.get('browseId', ''),
            'title': item.get('title', item.get('name', 'Sans titre')),
            'artist': _extract_artist(item.get('artists')),
            'thumb': _extract_thumb(item.get('thumbnails')),
        }
    return None


def _extract_thumb(thumbnails):
    """Get the highest resolution thumbnail URL from a thumbnails list."""
    if not thumbnails or not isinstance(thumbnails, list):
        return ''
    # Sort by width descending, take largest
    try:
        sorted_thumbs = sorted(thumbnails, key=lambda t: t.get('width', 0), reverse=True)
        return sorted_thumbs[0].get('url', '')
    except Exception:
        return thumbnails[-1].get('url', '') if thumbnails else ''


def _extract_artist(artists):
    """Extract artist name string from artists list."""
    if not artists:
        return ''
    if isinstance(artists, str):
        return artists
    if isinstance(artists, list):
        names = [a.get('name', '') for a in artists if isinstance(a, dict)]
        return ', '.join(filter(None, names))
    return ''

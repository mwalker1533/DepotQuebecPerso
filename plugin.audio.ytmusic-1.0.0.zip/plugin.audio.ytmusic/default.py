# -*- coding: utf-8 -*-
"""
default.py — Entry point for YouTube Music Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import sys
import urllib.parse

from resources.lib import navig, auth


def main():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))

    action = params.get('action', '')

    if action == 'setup':
        auth.run_setup()

    elif action == 'clear_auth':
        if auth.clear_auth():
            import xbmcgui
            xbmcgui.Dialog().notification(
                'YouTube Music',
                'Authentification supprimée',
                xbmcgui.NOTIFICATION_INFO
            )

    elif action == 'home':
        navig.show_home()

    elif action == 'liked_songs':
        navig.show_liked_songs()

    elif action == 'library_playlists':
        navig.show_library_playlists()

    elif action == 'library_albums':
        navig.show_library_albums()

    elif action == 'library_artists':
        navig.show_library_artists()

    elif action == 'playlist_tracks':
        playlist_id = params.get('playlist_id', '')
        if playlist_id:
            navig.show_playlist_tracks(playlist_id)

    elif action == 'album_tracks':
        browse_id = params.get('browse_id', '')
        if browse_id:
            navig.show_album_tracks(browse_id)

    elif action == 'artist':
        browse_id = params.get('browse_id', '')
        if browse_id:
            navig.show_artist(browse_id)

    elif action == 'search':
        navig.show_search()

    elif action == 'play':
        video_id = params.get('video_id', '')
        if video_id:
            navig.play_song(video_id)

    else:
        navig.show_main_menu()


if __name__ == '__main__':
    main()
